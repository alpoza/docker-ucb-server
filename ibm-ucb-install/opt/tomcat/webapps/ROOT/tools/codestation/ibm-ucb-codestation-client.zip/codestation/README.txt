CodeStation Ant Tasks Documentation
To use the CodeStation Ant Tasks, you need Ant installed. It is best practice to use the version of Ant that ships 
with IBM UrbanCode Build. However, if you need to use a different version of Ant, you will need to make sure
that the ibm-ucb-codestation-client-all.jar file is placed in a ~/.ant/lib directory within the user's home directory
(create the directories if not present). Once that is done, you can start using Ant Tasks.
To use the Ant Tasks in your Ant script, just add the CodeStation name space in the Ant project tag:

<project name="ibm_ucb_ant_client"
    xmlns:codestation="antlib:com.urbancode.ubuild.codestation.client"> ....
</project>
For examples of Ant Task scripts, see \codestation\examples in the CodeStation Client.



CodeStation CLI Documentation
Requirements: The CodeStation CLI is downloaded from the IBM UrbanCode Build server Tools page packaged as a zip file.
To extract it, you need a unzip utility. In order to run the CodeStation scripts, you will need to have Java 1.6 or
higher installed. The scripts also make the assumption that Java is on your system's PATH, but the scripts can be
modified to use an absolute path to the Java executable.

The CodeStation client zip file can be extracted to a directory and shell scripts to run the command-line client
will be available in the directory created by the extract. To see the help message, run "codestation -?" or
"codestation -help"

CLI Usage Examples:
Resolve all current dependencies for a project to the current directory:
codestation -p "My Project" -bp Build dependencies

Resolve all dependencies for an existing build life of a project by its id to the current directory:
codestation -bl 584 dependencies

Retrieve artifacts of a artifact set from the latest build life of a project:
codestation -p "My Project" -bp Build -set artifacts download

Retrieve artifacts of a artifact set from the latest build life of a project matching a status and stamp pattern:
codestation -p "My Project" -bp Build -set artifacts -status Success -stamp '1.0.*' download



You will want to create a file to store your configuration for CodeStation. CodeStation looks for a file named
ibm-ucb-cs.properties in your user home directory's .codestation directory. Go to your user home
directory and make this directory ( mkdir .codestation ). In that directory create a ibm-ucb-cs.properties file.
Open it and add the following properties (replace the values as appropriate):

codestation.server=https://ibm-ucb.yourdomain.com
codestation.user=username
codestation.password=password

Your password will be encrypted on the first use.

Username and password can be replaced is you have one by setting:
codestation.authToken=...